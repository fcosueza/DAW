# Web de AdminSYS

Se ha realizado la Web de la empresa AdminSYS. Para estructurar mejor el proyecto, se han creado
diferentes directorios donde guardar los diferentes. Los directorios son los siguientes:

- desing: en este directorio esta almacenado el archivo HTML de la maqueta
- fonts: directorio que almacena las fuentes usadas de forma local.
- images: imágenes usadas en la página web.
- style: archivos de estilo, incluidos el archivo principal estilo.css y el de la maqueta,
  maqueta.css

NOTA: todas las clases han sido nombradas en ingles. Por norma general suelo hacerlo así, y cuando
intento nombrarlas en español a veces se me pasa alguno y queda una mezcolanza de spanglish que no
queda nada bien. Si esto supone algún problema lo volveré a hacer en español.
