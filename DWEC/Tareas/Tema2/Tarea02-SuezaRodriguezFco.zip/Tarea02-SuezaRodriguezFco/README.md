# Tarea 2: Desarrollo Web en el Entorno Cliente

Se ha creado una estructura de directorios para que el contenido este un poco más ordenado. Así que
podemos encontrar todos los archivos javascript en el directorio js y los archivos html en pages.

La función auxiliar loadIframe() tambien se ha incluído en el directorio js, que se encarga de
cargar los iFrames con los archivos html adecuados.
