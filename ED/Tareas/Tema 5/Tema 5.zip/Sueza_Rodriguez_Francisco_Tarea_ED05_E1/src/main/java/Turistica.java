public class Turistica extends Ciudad {

	private String[] PuntosInteres;

	public String[] getPuntosInteres() {
		// TODO - implement Turistica.getPuntosInteres
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param puntoInteres
	 */
	public void insertarPuntoInteres(String puntoInteres) {
		// TODO - implement Turistica.insertarPuntoInteres
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param puntoInteres
	 */
	public void eliminarPuntoInteres(String puntoInteres) {
		// TODO - implement Turistica.eliminarPuntoInteres
		throw new UnsupportedOperationException();
	}

}