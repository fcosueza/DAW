public class Industrial extends Ciudad {

	private String[] industriasPrincipales;

	public String[] getIndustriasPrincipales() {
		return this.industriasPrincipales;
	}

	/**
	 * 
	 * @param industriaPrincipal
	 */
	public void insertarIndustriaPrincipal(String industriaPrincipal) {
		// TODO - implement Industrial.insertarIndustriaPrincipal
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param industriaPrincipal
	 */
	public void eliminarIndustriaPrincipal(String industriaPrincipal) {
		// TODO - implement Industrial.eliminarIndustriaPrincipal
		throw new UnsupportedOperationException();
	}

}