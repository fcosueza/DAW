/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sueza_rodriguez_francisco_tarea_ed05_e1;

/**
 *
 * @author fcosueza
 */
public class Sueza_Rodriguez_Francisco_Tarea_ED05_E1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
