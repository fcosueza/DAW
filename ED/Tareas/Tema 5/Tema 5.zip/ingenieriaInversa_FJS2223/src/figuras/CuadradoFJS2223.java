package figuras;

/**
 *
 * @author Ana Espina Martínez
 */
public class CuadradoFJS2223 extends Rectangulo {

    public CuadradoFJS2223(double lado) {
        super(lado, lado);
    }
    
}
