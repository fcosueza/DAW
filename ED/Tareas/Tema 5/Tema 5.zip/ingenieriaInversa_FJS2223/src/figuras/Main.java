package figuras;

/**
 *
 * @author Ana Espina Martínez
 */
public class Main {

    public static void main(String[] args) {
        
        CuadradoFJS2223 cuadrado = new CuadradoFJS2223(5);
        
        System.out.println("Area: " + cuadrado.getArea());
        System.out.println("Perímetro: " + cuadrado.getPerimetro());
        
    }
    
}
