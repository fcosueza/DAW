<?php

  define("VIRUS_TOTAL_API_KEY", "2da52e52f26e253b000430e6a65fb58a142a76cb57c8fcb32969d1991cf15af3");
  define("DATOS", __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'subidas' . DIRECTORY_SEPARATOR . 'datos_archivos_subidos.ser');
  define("CARPETA_SUBIDAS", __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'subidas');
