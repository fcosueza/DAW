<head>
    <nav>
        <ul>
            <li><a role='button' href="/ubicaciones">Lista de ubicaciones</a></li>
            <li><a role='button' href="/ubicaciones/create">Crear nueva ubicación</a></li>
        </ul>
    </nav>
</head>
<?php /**PATH C:\onedrive\OneDrive - iesaguadulce.es\I.E.S. Aguadulce 2023-2024\DWES\UT05\dwes05_sol\resources\views/layouts/menu.blade.php ENDPATH**/ ?>