<?php $__env->startSection('titulo','Lista de ubicaciones'); ?>
<?php $__env->startSection('content'); ?>
    <table>
        <thead>
            <tr>
                <th>Id</th><th>Nombre</th><th>Descripcion</th><th>Días</th><th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ubicacion->id); ?></td>
                <td><?php echo e($ubicacion->nombre); ?></td>
                <td><?php echo e($ubicacion->descripcion); ?></td>
                <td><?php echo e($ubicacion->dias); ?></td>
                <td>
                    <a href="<?php echo e(route('ubicaciones.show',['ubicacion'=>$ubicacion->id])); ?>" role="button-sm">Detalle ubicación</a>
                    <a href="<?php echo e(route('ubicaciones.edit',['ubicacion'=>$ubicacion->id])); ?>" role="button-sm">Editar ubicación</a>
                    <a href="<?php echo e(route('ubicaciones.destroyconfirm',['ubicacion'=>$ubicacion->id])); ?>" role="button-sm">Borrar ubicación</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\profesorado\OneDrive - iesaguadulce.es\I.E.S. Aguadulce 2023-2024\DWES\UT05\dwes05_sol\resources\views/ubicaciones.blade.php ENDPATH**/ ?>