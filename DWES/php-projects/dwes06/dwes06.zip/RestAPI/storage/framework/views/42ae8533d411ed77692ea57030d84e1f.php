<?php $__env->startSection('titulo', 'Formulario para crear ubicaciones'); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="/ubicaciones/<?php echo e($ubicacion->id); ?>/update" method="post">
    <?php echo csrf_field(); ?>
    Nombre: <input type="text" name="nombre" value="<?php echo e(old('nombre',$ubicacion->nombre)); ?>"><BR>
    Descripcion: <input type="text" name="descripcion" value="<?php echo e(old('descripcion',$ubicacion->descripcion)); ?>"><BR>
    Días en los que está disponible:<BR>
    <?php $__currentLoopData = ['L','M','X','J','V','S','D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($dia); ?> <input type="checkbox" name='dias[]'
                  value="<?php echo e($dia); ?>" <?php if(in_array($dia,old('dias',explode(',',$ubicacion->dias)))): echo 'checked'; endif; ?>>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <bR>
    <input type="submit" value="Modificar ubicación">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\onedrive\OneDrive - iesaguadulce.es\I.E.S. Aguadulce 2023-2024\DWES\UT05\dwes05_sol\resources\views/ubicaciones/edit.blade.php ENDPATH**/ ?>