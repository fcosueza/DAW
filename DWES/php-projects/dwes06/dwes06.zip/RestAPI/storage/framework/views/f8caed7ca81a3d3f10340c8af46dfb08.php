<?php $__env->startSection('titulo', 'Formulario para crear ubicaciones'); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="/ubicaciones/<?php echo e($ubicacion); ?>/destroy" method="post">
    <?php echo csrf_field(); ?>
    Debe confirmar la eliminación para continuar, dado que se borrarán también todos los talleres de esta ubicación:<BR>
    <input type="radio" name="confirmar" value='si'> Si, quiero borrar esta ubicación y los talleres.<BR>
    <input type="radio" name="confirmar" value='no' checked> No, no quiero borrar la ubicación.<BR>
    <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\onedrive\OneDrive - iesaguadulce.es\I.E.S. Aguadulce 2023-2024\DWES\UT05\dwes05_sol\resources\views/ubicaciones/destroyconfirm.blade.php ENDPATH**/ ?>