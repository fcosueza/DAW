<?php $__env->startSection('titulo', 'Formulario para crear ubicaciones'); ?>
<?php $__env->startSection('content'); ?>
   <B>Nombre</B>: <?php echo e($ubicacion->nombre); ?><BR>
   <B>Descripcion</B>: <?php echo e($ubicacion->descripcion); ?><BR>
   <B>Dias disponible</B>: <?php echo e($ubicacion->dias); ?><BR>

   <B>Listado de talleres:</B>
   <?php if($ubicacion->talleres->count()>0): ?>
   <table border="1">
    <thead>
        <tr><th>Nombre</th><th>Descripcion</th><th>Dia de la semana</th><th>Hora de inicio</th><th>Hora de fin</th><th>Cupo</th></tr>
    </thead>
    <tbody>
   <?php $__currentLoopData = $ubicacion->talleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr><td><?php echo e($taller->nombre); ?></td><td><?php echo e($taller->descripcion); ?></td><td><?php echo e($taller->dia_semana); ?></td>
            <td><?php echo e($taller->hora_inicio); ?></td><td><?php echo e($taller->hora_fin); ?></td><td><?php echo e($taller->cupo_maximo); ?></td></tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   </table>
   <?php else: ?>
       No hay talleres previstos en esta ubicación.
   <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\onedrive\OneDrive - iesaguadulce.es\I.E.S. Aguadulce 2023-2024\DWES\UT05\dwes05_sol\resources\views/ubicaciones/detalleubicacion.blade.php ENDPATH**/ ?>