<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
    <title>Bienvenidos a Respira</title>
</head>
<body>
    <H1>Bienvenido a la asociación Respira</H1>
    <div class="content">
    <a href="ubicaciones">Listar ubicaciones de los talleres.</a>
    </div>
</body>
</html>
