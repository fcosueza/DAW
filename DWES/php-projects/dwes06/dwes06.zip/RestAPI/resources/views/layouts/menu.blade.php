<head>
    <nav>
        <ul>
            <li><a role='button' href="/ubicaciones">Lista de ubicaciones</a></li>
            <li><a role='button' href="/ubicaciones/create">Crear nueva ubicación</a></li>
        </ul>
    </nav>
</head>
