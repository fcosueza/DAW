<?php
/* Smarty version 4.3.1, created on 2024-03-26 10:35:22
  from '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_660296da8dc758_59043189',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd54ddc21a81fdb664a99fadd71f4fa7573959b7d' => 
    array (
      0 => '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/header.tpl',
      1 => 1711445701,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_660296da8dc758_59043189 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="author" content="Francisco Sueza Rodríguez" />
        <meta name="description" content="Página con los talleres de la Asociación Respira" />

        <link href="public/css/style.css" rel="stylesheet" type="text/css"/>

        <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
    </head>
    <body class="flex center">
        <h1 class="title"><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h1>

<?php }
}
