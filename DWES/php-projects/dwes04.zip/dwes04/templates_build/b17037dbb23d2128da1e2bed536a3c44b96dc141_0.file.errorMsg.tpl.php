<?php
/* Smarty version 4.3.1, created on 2024-03-27 12:51:22
  from '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/components/errorMsg.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6604083a12a652_17191340',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b17037dbb23d2128da1e2bed536a3c44b96dc141' => 
    array (
      0 => '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/components/errorMsg.tpl',
      1 => 1711537345,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6604083a12a652_17191340 (Smarty_Internal_Template $_smarty_tpl) {
?><p class="error"><em><?php echo $_smarty_tpl->tpl_vars['errorMsg']->value;?>
</em></p>

<?php }
}
