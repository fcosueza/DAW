<?php
/* Smarty version 4.3.1, created on 2024-03-23 10:52:18
  from '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_65fea6528f3570_21692706',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d50122d555f407ab3bbc4ade5f4e21b4286dfc9' => 
    array (
      0 => '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/footer.tpl',
      1 => 1711102927,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65fea6528f3570_21692706 (Smarty_Internal_Template $_smarty_tpl) {
?></body>
</html>
<?php }
}
