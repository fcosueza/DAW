<?php
/* Smarty version 4.3.1, created on 2024-03-27 10:12:19
  from '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/components/addTallerButton.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6603e2f324df84_18458421',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd988eb066c278f198dcc5518fdc11be0cf14e270' => 
    array (
      0 => '/home/fcosueza/Source/DAW/DWES/php-projects/dwes04/templates/components/addTallerButton.tpl',
      1 => 1711530736,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6603e2f324df84_18458421 (Smarty_Internal_Template $_smarty_tpl) {
?><form class="buttonForm" action="?accion=nuevo_taller_form" method="post">
    <button class="form__button" type="submit">Añadir Taller</button>
</form>
<?php }
}
