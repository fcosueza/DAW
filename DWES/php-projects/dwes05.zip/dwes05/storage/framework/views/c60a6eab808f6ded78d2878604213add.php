
<html xmlns="http://www.w3.org/1999/xhtml" lang="es">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="author" content="Francisco Sueza Rodríguez" />
        <meta name="description"  content="Página de gestión de talleres de la Asociación Respira" />

        <link rel="stylesheet" href="<?php echo e(asset('/assets/css/app.css')); ?>" />

        <title><?php echo $__env->yieldContent('titulo'); ?> - Asociación Respira</title>
    </head>

    <body>

    <header class="flex center header">
        <form action="/ubicaciones/create" method="GET">
            <button class="button">Crear Ubicación</button>
        </form>
        <form action="/ubicaciones" method="GET">
            <button class="button" >Lista de Ubicaciones</button>
        </form>
    </header>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH /home/fcosueza/Source/DAW/DWES/php-projects/dwes05/resources/views/layouts/base.blade.php ENDPATH**/ ?>