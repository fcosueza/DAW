<?php $__env->startSection('titulo', 'Información de Ubicacion'); ?>

<?php $__env->startSection('content'); ?>

    <div class="info">
        <strong>Nombre:</strong> <?php echo e($ubicacion->nombre); ?><br>
        <strong>Descripcion:</strong> <?php echo e($ubicacion->descripcion); ?><br>
        <strong>Dias Semana:</strong> <?php echo e($ubicacion->dias); ?><br>

        <br>
        <strong>Lista de Talleres: </strong>
    </div>
    <table class="table">
        <thead class="table__head">
            <tr>
                <th class="table__cell">Nombre</th>
                <th class="table__cell">Descripcion</th>
                <th class="table__cell">Dia de la Semana</th>
                <th class="table__cell">Hora de Inicio</th>
                <th class="table__cell">Hora de Fin</th>
                <th class="table__cell">Cupo Máximo</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $talleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="table__cell"><?php echo e($taller->nombre); ?></td>
                    <td class="table__cell"><?php echo e($taller->descripcion); ?></td>
                    <td class="table__cell"><?php echo e($taller->dia_semana); ?></td>
                    <td class="table__cell"><?php echo e($taller->hora_inicio); ?></td>
                    <td class="table__cell"><?php echo e($taller->hora_fin); ?></td>
                    <td class="table__cell"><?php echo e($taller->cupo_maximo); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fcosueza/Source/DAW/DWES/php-projects/dwes05/resources/views/ubicaciones/detalleubicacion.blade.php ENDPATH**/ ?>