<?php $__env->startSection('titulo','Lista de ubicaciones'); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead class="table__head">
            <tr>
                <th class="table__cell">Id</th>
                <th class="table__cell">Nombre</th>
                <th class="table__cell">Descripcion</th>
                <th class="table__cell">Días</th>
                <th class="table__cell">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="table__cell"><?php echo e($ubicacion->id); ?></td>
                    <td class="table__cell"><?php echo e($ubicacion->nombre); ?></td>
                    <td class="table__cell"><?php echo e($ubicacion->descripcion); ?></td>
                    <td class="table__cell"><?php echo e($ubicacion->dias); ?></td>
                    <td class="table__cell">
                        <form action="/ubicaciones/<?php echo e($ubicacion->id); ?>" method="GET">
                            <button class="button table__button">Detalles Ubicación</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fcosueza/Source/DAW/DWES/php-projects/dwes05/resources/views/ubicaciones.blade.php ENDPATH**/ ?>