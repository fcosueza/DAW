<?php $__env->startSection('titulo', 'Creacion de Ubicacion'); ?>

<?php $__env->startSection('content'); ?>


    <form class="form flex center" action="/ubicaciones/store" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form__header">
            <h3>Nueva Ubicación</h3>
        </div>

        <div class="form__control flex">
            <label for="nombre">Nombre:</label>
            <input class="form__input" type="text" name="nombre" id="nombre">
        </div>
        <div class="form__control flex">
            <label for="descripcion">Descripcion:</label>
            <input class="form__input"type="text" name="descripcion" id="descripcion">
        </div>

        <div class="form__control">
            <label>Dias en los que está disponible: </label><br>
            <?php $__currentLoopData = ['L', 'M', 'X', 'J', 'V', 'S', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($dia); ?> <input class="form__check" type="checkbox" name="dias[]" value="<?php echo e($dia); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <br>

        <button class="form__button" type="submit">Crear Ubicacion</button>
    </form>

    <?php if($errors->any()): ?>
        <div class="error__container">
            <h2 class="error__title">Errores: </h2>
            <ul class="error__list">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="error__msg"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fcosueza/Source/DAW/DWES/php-projects/dwes05/resources/views/ubicaciones-create.blade.php ENDPATH**/ ?>