<?php

  /*
   * Definición de los datos de conexión de la base de datos.
   */

  define('HOST', 'localhost');
  define('DB', 'respira');
  define('USER', 'respira');
  define('PASSWORD', 'AbC1234.');
